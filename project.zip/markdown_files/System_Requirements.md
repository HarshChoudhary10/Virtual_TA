---
title: "System Requirements"
original_url: "https://tds.s-anand.net/#/system-requirements?id=system-requirements"
downloaded_at: "2025-11-17T09:22:11.419361"
---

[System Requirements](#/system-requirements?id=system-requirements)
===================================================================

This course requires the following:

* [Software](#/system-requirements?id=software) to be installed on your computer.
* [System permissions](#/system-requirements?id=system-permissions) to be granted.
* Access to the [Websites](#/system-requirements?id=websites) listed below.

[Software](#/system-requirements?id=software)
---------------------------------------------

Core tools:

* [Visual Studio Code](https://code.visualstudio.com/)
* [uv](https://docs.astral.sh/uv/getting-started/installation/) for Python
* [NodeJS](https://nodejs.org/) for JavaScript
* [Docker](https://www.docker.com/) or [Podman](https://podman.io/getting-started/installation)
* [GitHub Copilot](https://github.com/features/copilot)

Module-specific tools:

* [DBeaver](https://dbeaver.io/)
* [DuckDB](https://duckdb.org/)
* [Excel](https://www.microsoft.com/en-in/microsoft-365/excel)
* [FFMpeg](https://ffmpeg.org/)
* [GitHub CLI](https://cli.github.com/)
* [GitHub Desktop](https://desktop.github.com/)
* [llm](https://llm.datasette.io/)
* [Lynx](https://lynx.invisible-island.net/)
* [MuPDF](https://mupdf.com/)
* [OBS Studio](https://obsproject.com/)
* [Ollama](https://ollama.com/)
* [OpenRefine](https://openrefine.org)
* [Pandoc](https://pandoc.org/)
* [pdftotext](https://www.xpdfreader.com/pdftotext-man.html)
* [Playwright](https://playwright.dev/python/docs/intro)
* [QGIS](https://www.qgis.org/en/site/)
* [sqlite-utils](https://sqlite-utils.datasette.io/)
* [SQLiteStudio](https://sqlitestudio.pl/)
* [TypeSense](https://typesense.org/docs/guide/install-typesense.html)
* [w3m](https://w3m.sourceforge.net/)
* [wget](https://www.gnu.org/software/wget/)
* [Whisper](https://github.com/Purfview/whisper-standalone-win/releases)
* [yt-dlp](https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp)

[System permissions](#/system-requirements?id=system-permissions)
-----------------------------------------------------------------

* Open Developer Tools on Chrome / Edge - to use F12 or Inspect in browser
* Open port 8000-9000 for local development server
* `pip install` and `npm install` to install packages

[Websites](#/system-requirements?id=websites)
---------------------------------------------

* accounts.google.com
* agents.md
* ai.google.dev
* aipipe.org
* aiproxy.sanand.workers.dev
* aircloak.com
* airflow.apache.org
* aistudio.google.com
* anthropic.com
* api-atlas.nomic.ai
* api.example.com
* apify.com
* api.jina.ai
* api.openai.com
* api.open-notify.org
* app.example.com
* app.flourish.studio
* apple.com
* appsource.microsoft.com
* arxiv.org
* aspiegel.com
* atlas.nomic.ai
* azure.microsoft.com
* base64decode.org
* bbc.com
* beautiful-soup-4.readthedocs.io
* bing.com
* blog.gramener.com
* bolt.new
* calendar.google.com
* cb-prod.seek.study.iitm.ac.in
* cdn.jsdelivr.net
* cdn.openai.com
* chat.deepseek.com
* chatgpt.com
* chat.openai.com
* chat.qwen.ai
* claude.ai
* cli.github.com
* cline.bot
* cloud.google.com
* cmdlinetips.com
* codeium.com
* code.visualstudio.com
* coffee-reviews.prayashm.com
* colab.research.google.com
* console.cloud.google.com
* context7.com
* continue.dev
* cors-test.codehappy.devs
* cran.r-project.org
* cursor.com
* cyberscoop.com
* dashboard.ngrok.com
* dataforseo.com
* data.gov
* data.gov.in
* data.gov.ru
* datameet.org
* datasetsearch.research.google.com
* datasets.imdbws.com
* datasette.io
* dbeaver.io
* dbfopener.com
* deepwiki.com
* desktop.github.com
* devanshikat.github.io
* developer.chrome.com
* developer.imdb.com
* developer.mozilla.org
* developers.googleblog.com
* developers.google.com
* dev.mysql.com
* discourse.onlinedegree.iitm.ac.in
* diva-gis.org
* dl.acm.org
* docker.com
* docs.anthropic.com
* docs.astral.sh
* docs.cursor.com
* docs.docker.com
* docs.getdbt.com
* docs.github.com
* docs.google.com
* docs.klarna.com
* docs.kumu.io
* docs.lovable.dev
* docs.nomic.ai
* docs.npmjs.com
* docs.python.org
* docs.python-requests.org
* docs.replit.com
* docs.sqlalchemy.org
* docs.together.ai
* docs.windsurf.com
* dopiaza.org
* drive.google.com
* drive.usercontent.google.com
* duckdb.org
* elastic.co
* en.wikipedia.org
* evanhahn.github.io
* example.com
* exam.sanand.workers.dev
* explainxkcd.com
* fastapi.tiangolo.com
* fastapi-users.github.io
* ffmpeg.lav.io
* ffmpeg.org
* flourish.studio
* flukeout.github.io
* fmwconcepts.com
* forms.gle
* freecodecamp.org
* gemini.google
* gemini.google.com
* generativelanguage.googleapis.com
* geopy.readthedocs.io
* getdbt.com
* github.com
* github.github.com
* gitingest.com
* gitlab.com
* gitlens.amod.io
* git-lfs.github.com
* git-scm.com
* gnu.org
* googlecloudcommunity.com
* google.com
* gramener.com
* groups.google.com
* heroku.com
* howstat.com
* httpbin.org
* httpie.io
* httrack.com
* hub.docker.com
* hub.getdbt.com
* huggingface.co
* imagemagick.org
* imageoptim.com
* imdb.com
* imgs.xkcd.com
* img.youtube.com
* i.ytimg.com
* jamendo.com
* jeroenjanssens.com
* jina.ai
* jmespath.org
* jqlang.org
* jqplay.org
* jsoneditoronline.org
* json-generator.com
* jsonlines.org
* jsonlint.com
* jsonpath.com
* jsonpathfinder.com
* json-schema.org
* jsonschemavalidator.net
* judgments.ecourts.gov.in
* kaggle.com
* keras.io
* khanacademy.org
* kumu.io
* learn.microsoft.com
* linkedin.com
* llm.datasette.io
* llmstxt.org
* localhost
* locator-service.api.bbci.co.uk
* lovable.dev
* lxml.de
* lynx.invisible-island.net
* macstories.net
* magickstudio.imagemagick.org
* mail.google.com
* makersuite.google.com
* mapshaper.org
* marimo.app
* marimo.io
* marketplace.visualstudio.com
* marp.app
* matplotlib.org
* medium.com
* microsoft.com
* mistral.ai
* modelcontextprotocol.io
* mongodb.com
* mupdf.com
* nchandrasekharr.github.io
* news.ycombinator.com
* ngrok.com
* nodejs.org
* nominatim.org
* notebooklm.google.com
* npmjs.com
* numpy.org
* observablehq.com
* obsproject.com
* ollama.com
* openai.com
* openpolicyagent.org
* openrefine.org
* openrouter.ai
* ourworldindata.org
* packaging.python.org
* pages.github.com
* pandas.pydata.org
* pandoc.org
* parquet.apache.org
* pillow.readthedocs.io
* platform.openai.com
* playwright.dev
* pngquant.org
* podman.io
* pokeapi.co
* posit.co
* postgresql.org
* postman.com
* pre-commit.com
* projector.tensorflow.org
* promptfoo.dev
* pydantic-docs.helpmanual.io
* pymotw.com
* pymupdf.readthedocs.io
* pypi.org
* python-httpx.org
* python-visualization.github.io
* qgis.org
* quotes.toscrape.com
* rasagy.in
* rattle.togaware.com
* raw.githubusercontent.com
* rawgraphs.io
* realpython.com
* redis.io
* relational-data.org
* revealjs.com
* rishabhmakes.github.io
* roocode.com
* sanand0.github.io
* s-anand.net
* scikit-learn.org
* scikit-network.readthedocs.io
* screentogif.com
* seaborn.pydata.org
* seek.onlinedegree.iitm.ac.in
* senate.gov
* shapechef.com
* sharp.pixelplumbing.com
* simonwillison.net
* soundcloud.com
* sourceforge.net
* sqlite.org
* sqlitestudio.pl
* sqlite-utils.datasette.io
* sqlmodel.tiangolo.com
* sqlzoo.net
* squoosh.app
* stackoverflow.blog
* stackoverflow.com
* statsmodels.org
* stats.stackexchange.com
* stedolan.github.io
* story-b0f1c.web.app
* storytellingwithdata.com
* study.iitm.ac.in
* superlinked.com
* support.anthropic.com
* support.apple.com
* support.google.com
* support.microsoft.com
* support.office.com
* survey.stackoverflow.co
* swagger.io
* tableau.com
* tabula-py.readthedocs.io
* tds.s-anand.net
* textblob.readthedocs.io
* texttospeech.googleapis.com
* thoughtworks.com
* timeanddate.com
* tools.s-anand.net
* tracebit.com
* twitter.com
* typesense.org
* unstructured.io
* upload.wikimedia.org
* url.com
* us-central1-aiplatform.googleapis.com
* vercel.com
* w3m.sourceforge.net
* w3.org
* weather-broker-cdn.api.bbci.co.uk
* web.archive.org
* webmaster.petalsearch.com
* whitehouse.gov
* whois.com
* wikipedia.readthedocs.io
* windsurf.com
* wordlift.io
* xpdfreader.com
* yoast.com
* your-app.vercel.app
* youtu.be
* youtube.com
* youtubetranscript.com

[Previous

Sep 2025: Tools in Data Science](#/README)

[Next

Marks Dashboard](#/marks-dashboard)